ShowHiddenChannels Kettu custom port

This is a Kettu/Vendetta-style plugin package containing manifest.json + index.js.
It only inspects channel metadata already cached by the Discord client and displays names that the client knows but the current user cannot view.
It does NOT fetch, decrypt, or read messages from hidden channels.

Important: Discord's newer private-channel-hiding behavior can prevent the real channel name from ever reaching the client. In that case the plugin cannot recover it.

Install: Kettu > Plugins > + > paste the public folder URL containing manifest.json and index.js.
